export default [
  {
    title: 'Home',
    url: '/'
  },
  {
    title: 'About Us',
    url: '/about'
  },
  {
    title: 'Contact Us',
    url: '/contact'
  },
  {
    title: 'Library',
    url: '/library'
  }
];
