export const API = Object.freeze({
  LIBRARY: {
    BOOK: 'library/book',
    BOOKS: 'library/books'
  }
});
