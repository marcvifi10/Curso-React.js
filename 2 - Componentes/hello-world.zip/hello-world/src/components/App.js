import React from 'react';
import logo from './logo.svg';
import './App.css';

// Components
import header from './global/header'

function App() {
  return (
    <div className="App">
	  <header />
    </div>
  );
}

export default App;
